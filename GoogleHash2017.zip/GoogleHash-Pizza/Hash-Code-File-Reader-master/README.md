# Hash-Code-File-Reader
An example repo showing how the .in files given for the Google Hash code can be turned into a list 
of objects that can be processed for the challenge.

## Example Problem: Pizza
The example problem given out by Google before their annual Hash Code event is the "Pizza Problem". 
[A complete copy of the challenge is in the root of the repo](pizza.pdf).