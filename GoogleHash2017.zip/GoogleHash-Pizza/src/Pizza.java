import java.util.ArrayList;

public class Pizza
{
	private int rows;
	private int columns;
	private int min;
	private int max;
	private int minValidSliceSize;
	private char[][] pizzaGrid;
	private ArrayList<String> smallSlices;
	private ArrayList<String> validSlices;


	/**
	 * Create a new Pizza object
	 * @param min
	 * @param max
	 * @param pizza
	 */
	public Pizza(int min, int max, char[][] pizza)
	{
		this.rows = pizza.length;
		this.columns = pizza[0].length;
		this.min = min;
		this.max = max;
		minValidSliceSize = min * 2; //Minimum ingredients x2

		pizzaGrid = pizza;
		//Instantiate arrayLists
		smallSlices = new ArrayList<String>();
		validSlices = new ArrayList<String>();
	}
	
	/**
	 * @return the smallSlices
	 */
	public ArrayList<String> getSmallSlices() {
		return smallSlices;
	}

	/**
	 * @return the validSlices
	 */
	public ArrayList<String> getValidSlices() {
		return validSlices;
	}



	/**
	 * get the number of rows the pizza has
	 * @return int
	 */
	public int getRows()
	{
		return rows;
	}

	/**
	 * get the number of columns the pizza has
	 * @return int
	 */
	public int getColumns()
	{
		return columns;
	}

	/**
	 * get the minimum number of topping count per slice
	 * @return int
	 */
	public int getMin()
	{
		return min;
	}

	/**
	 * get the maximum number of topping count per slice
	 * @return
	 */
	public int getMax()
	{
		return max;
	}

	/**
	 * get the char grid representing the pizza
	 * @return char[][]
	 */
	public char[][] getPizzaGrid()
	{
		return pizzaGrid;
	}

	/**
	 * Print information about the pizza in a formatted manner
	 */
	public void printDetails()
	{
		System.out.println(rows + "*" + columns + "\t\tMin: " + min + "\t\tMax: " + max);
		for (int i = 0; i < pizzaGrid.length; i++)
		{
			for (int j = 0; j < pizzaGrid[i].length; j++)
			{
				System.out.print(pizzaGrid[i][j]);
			}
			System.out.print("\n");
		}
	}
	
	/**
	 * Slice the pizza and display the slices
	 * 
	 *	 T M M M T T T			// Start by looking at one row, how long is it? can a slice be made purely from max cells?
	 *	 M M M M T M M			// if not, can it be made from minimum cells? can you fill in the gaps?
	 *	 T T M T T M T
	 *	 T T T T T T M			// Would a good solution be, working from left to right to find the smallest slice, THEN working
	 *	 T T T T T T M			// from right to left and doing the same, then repeat. If the middle doesn't make a slice, can it be added
	 *							// onto the left or right slice (assuming they didn't reach the maximum number of cells)
	 *
	 * Alternatively, you can make as large a slice from left to right up until you encounter a different topping (as many as minimum) 
	 * Then you assume their will be just as many of the opposite toppings later, to become a slice.
	 * 
	 * Another way of seeing it is that T = 1, M = 0;
	 * Then we can create a truth table of:
	 * 		1 1	-no
	 * 		1 0	-yes
	 * 		0 1	-yes
	 * 		0 0	-no
	 * which shows an XOR logic gate. As we only ever get a T or M we can apply binary.
	 * We also know that the number of ingredients will have to be doubled, causing the 
	 * smallest slices being [number of ingredients per slice x2] which is always an even number.
	 * 
	 *  With this in mind, we can go through the data and find all the smallest possible slices, then 
	 *  we can measure the gap between valid slices and see if we can add extra cells that don't make 
	 *  their own slice onto an existing valid slice.
	 *  
	 *  
	 */							
	public void slicePizza()
	{
		String slice = "";
		String lastSlice = "";
		int tCount = 0;
		int mCount = 0;
		int cellCount = 0;
		int cellsLeft = 0;
		
		for (int i = 0; i < pizzaGrid.length; i++) //Go through each row
		{
			for (int j = 0; j < pizzaGrid[i].length; j++) //Go through each column
			{
				//Increment counter(s) by 1
				cellCount++;
				cellsLeft++;
				//If cellCount is greater than the max number of cells permitted then reset variables
				if(cellCount > max)
				{
					slice = "";
					tCount = 0;
					mCount = 0;
					cellCount = 0;
				}
				
				//Read the character, increment correct counter by 1
				if(pizzaGrid[i][j] == 'M')
					mCount++;
				else
					tCount++;
				
				//Add new character to string
				slice += pizzaGrid[i][j];
				
				//Check for a valid slice
				if(mCount >= min && tCount >= min && cellCount <= max)
				{
					//At this point, we know that this is a small, but good slice
					//We can copy a binary trees 'in-order' traversal, where the root is the slice, and left is left of the slice... etc 
										
					//Figure out if there is any unused cells to the left
					cellsLeft -= slice.length()*2; //cellsLeft now represent the number of cells free to the left of the slice including the slice
					//Add any free characters to the left onto the string
					if(cellsLeft > 0 && cellsLeft <= max)
					{
						String newSlice = "";
						 for(int k = cellsLeft; k<=max; k++)
						 {
							 newSlice += (pizzaGrid[i][j-k]); //Working from the most left, add the unused cells to the slice
						 }
						 newSlice += slice;
						 slice = newSlice; //The slice is now, the unused slices to the left + the slice
					}
										
					//Add this slice assuming it still meets the criteria
					if(mCount >= min && tCount >= min && slice.length() <= max) 
					{						
						smallSlices.add(slice);
						lastSlice = slice;
					}

					//Reset the variables ready for the next slice
					slice = "";
					tCount = 0;
					mCount = 0;
					cellCount = 0;
				}
			}
			//If there is any toppings left at the end of the rows, store them (this will determine inefficiencies)
			if(slice != "")
			{
				
				if(slice.length() + lastSlice.length() <= max)
				{
					smallSlices.remove(lastSlice); //delete duplicates
					smallSlices.add(lastSlice + slice);
				}
				validSlices.add(slice);				
			}
			tCount = 0;
			mCount = 0;
			slice = "";
			cellCount = 0;
			cellsLeft = 0;
		}
	}
}
